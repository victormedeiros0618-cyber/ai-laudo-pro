import { useState } from 'react';
import { X, Loader, Play } from 'lucide-react';
import { FotoUploadB } from './FotoUploadB';
import { useFotoManager, type Foto } from '@/hooks/useFotoManager';
import { useAnaliseLaudo } from '@/hooks/useAnaliseLaudo';
import { toast } from 'sonner';
import type { RelatorioIA } from '@/types';

interface EvidenciasTabProps {
  tipoLaudo: string;
  laudoId?: string;
  fotos?: string[];
  onFotosChange?: (fotos: string[]) => void;
  onProcessed?: (result: RelatorioIA) => void;
  descricao?: string;
}

const BATCH_SIZE = 3;

export function EvidenciasTab({
  tipoLaudo,
  laudoId,
  onFotosChange,
  onProcessed,
  descricao,
}: EvidenciasTabProps) {
  const {
    fotos,
    removerFoto,
    atualizarAnaliseGemini,
    atualizarLoading,
    atualizarErro,
    fotosComAnalise,
    fotosSemAnalise,
  } = useFotoManager();

  const { analisarLote, loading: analisando } = useAnaliseLaudo();
  const [analisandoAgora, setAnalisandoAgora] = useState(false);

  console.log(`📊 AbaEvidencias renderizando: ${fotos.length} fotos totais`);

  // ✅ ANALISAR TODAS AS FOTOS EM LOTES
  const handleAnalisarTodas = async () => {
    // ✅ CHAMAR A FUNÇÃO para obter fotos sem análise
    const fotosPendentes = fotosSemAnalise();

    if (fotosPendentes.length === 0) {
      toast.info('Todas as fotos já foram analisadas');
      return;
    }

    setAnalisandoAgora(true);

    try {
      // Agrupar em lotes de BATCH_SIZE
      for (let i = 0; i < fotosPendentes.length; i += BATCH_SIZE) {
        const lote = fotosPendentes.slice(i, i + BATCH_SIZE);
        const numeroLote = Math.floor(i / BATCH_SIZE) + 1;
        const totalLotes = Math.ceil(fotosPendentes.length / BATCH_SIZE);

        console.log(`📦 Processando lote ${numeroLote}/${totalLotes} (${lote.length} fotos)`);
        toast.loading(`Analisando lote ${numeroLote}/${totalLotes}...`);

        // Marcar fotos como carregando
        lote.forEach((foto) => {
          atualizarLoading(foto.id, true);
        });

        // Analisar lote
        const resultados = await analisarLote(
          lote.map((f) => ({ id: f.id, file: f.file })),
          tipoLaudo,
          descricao
        );

        // Atualizar estado de cada foto
        resultados.forEach((analise, fotoId) => {
          if (analise) {
            atualizarAnaliseGemini(fotoId, analise);
            console.log(`✅ Foto ${fotoId} analisada`);
          } else {
            atualizarErro(fotoId, 'Erro ao analisar');
            console.error(`🔴 Erro ao analisar foto ${fotoId}`);
          }
        });

        // Aguardar 1 segundo entre lotes
        if (i + BATCH_SIZE < fotosPendentes.length) {
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }
      }

      toast.success('Análise de todas as fotos concluída!');
    } catch (err) {
      console.error('🔴 Erro ao analisar fotos:', err);
      toast.error('Erro ao analisar fotos');
    } finally {
      setAnalisandoAgora(false);
    }
  };

  // ✅ PROCESSAR E AVANÇAR
  const handleNext = () => {
    // ✅ CHAMAR A FUNÇÃO para obter fotos com análise
    const fotosAnalisadas = fotosComAnalise();

    const achados: any[] = [];
    let nivelRiscoGeral: 'baixo' | 'medio' | 'alto' | 'critico' = 'baixo';
    let resumoGeral = '';

    fotosAnalisadas.forEach((foto) => {
      if (!foto.analiseGemini) return;

      achados.push(...foto.analiseGemini.achados);
      resumoGeral += `\n${foto.analiseGemini.resumo_executivo}`;

      const niveis = ['baixo', 'medio', 'alto', 'critico'];
      const indexAtual = niveis.indexOf(nivelRiscoGeral);
      const indexNovo = niveis.indexOf(foto.analiseGemini.nivel_risco_geral);
      if (indexNovo > indexAtual) {
        nivelRiscoGeral = foto.analiseGemini.nivel_risco_geral;
      }
    });

    const resultadoFinal: RelatorioIA = {
      achados,
      resumo_executivo: `Análise de ${fotos.length} foto(s). Total de ${achados.length} achado(s) encontrado(s).${resumoGeral}`,
      nivel_risco_geral: nivelRiscoGeral,
    };

    console.log('🟢 Resultado final:', resultadoFinal);

    if (onProcessed) {
      onProcessed(resultadoFinal);
    }

    if (onFotosChange) {
      onFotosChange(fotos.map((f) => f.preview));
    }
  };

  // ✅ CONTAR FOTOS ANALISADAS
  const fotosAnalisadasArray = fotosComAnalise();
  const fotosPendentesArray = fotosSemAnalise();
  const totalFotos = fotos.length;
  const podeAvancar = totalFotos > 0 && fotosAnalisadasArray.length === totalFotos;

  console.log(`📊 Status: ${fotosAnalisadasArray.length}/${totalFotos} analisadas, ${fotosPendentesArray.length} pendentes, podeAvancar=${podeAvancar}`);

  return (
    <div className="space-y-6">
      {/* COMPONENTE DE UPLOAD */}
      <FotoUploadB tipoLaudo={tipoLaudo} descricao={descricao} />

      {/* EXIBIÇÃO DE FOTOS */}
      {fotos.length > 0 && (
        <div className="space-y-4 pt-6 border-t border-zinc-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Fotos Adicionadas</h3>
            <span className="text-sm text-zinc-500">
              {fotosAnalisadasArray.length} de {totalFotos} analisadas
            </span>
          </div>

          {/* BOTÃO ANALISAR TODAS */}
          {fotosPendentesArray.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-blue-900">
                    {fotosPendentesArray.length} foto(s) aguardando análise
                  </p>
                  <p className="text-xs text-blue-700 mt-1">
                    Clique em "Analisar Todas" para processar em lotes de {BATCH_SIZE} fotos
                  </p>
                </div>
                <button
                  onClick={handleAnalisarTodas}
                  disabled={analisandoAgora || analisando}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {analisandoAgora || analisando ? (
                    <>
                      <Loader size={16} className="animate-spin" />
                      Analisando...
                    </>
                  ) : (
                    <>
                      <Play size={16} />
                      Analisar Todas
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* GRID DE FOTOS */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {fotos.map((foto, idx) => (
              <div
                key={foto.id}
                className="border border-zinc-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* IMAGEM */}
                <div className="relative w-full h-40 bg-zinc-100">
                  <img
                    src={foto.preview}
                    alt={`Foto ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />

                  {/* LOADING OVERLAY */}
                  {foto.loading && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Loader size={20} className="text-white animate-spin" />
                    </div>
                  )}

                  {/* STATUS BADGE */}
                  <div
                    className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-semibold text-white ${foto.analiseGemini
                        ? 'bg-green-500'
                        : foto.error
                          ? 'bg-red-500'
                          : 'bg-yellow-500'
                      }`}
                  >
                    {foto.analiseGemini ? '✓ Analisada' : foto.error ? '✗ Erro' : '⏳ Pendente'}
                  </div>
                </div>

                {/* INFO */}
                <div className="p-3">
                  <h4 className="font-semibold text-sm mb-1">Foto {idx + 1}</h4>
                  <p className="text-xs text-zinc-600 mb-2 truncate">
                    {foto.file.name}
                  </p>

                  {foto.error && (
                    <p className="text-xs text-red-600 mb-2">❌ {foto.error}</p>
                  )}

                  {foto.analiseGemini && (
                    <div className="text-xs text-green-600 mb-2">
                      ✓ {foto.analiseGemini.achados.length} achado(s)
                    </div>
                  )}

                  <button
                    onClick={() => removerFoto(foto.id)}
                    className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
                  >
                    <X size={12} />
                    Remover
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* DETALHES DAS ANÁLISES */}
          {fotosAnalisadasArray.length > 0 && (
            <div className="space-y-4 pt-6 border-t border-zinc-200">
              <h3 className="text-lg font-semibold">Análises Detalhadas</h3>

              {fotosAnalisadasArray.map((foto, idx) => (
                <div
                  key={foto.id}
                  className="border border-zinc-200 rounded-lg p-4 bg-zinc-50"
                >
                  <h4 className="font-semibold text-sm mb-3">Foto {fotos.indexOf(foto) + 1}</h4>

                  {/* ACHADOS */}
                  {foto.analiseGemini!.achados.length > 0 && (
                    <div className="mb-4">
                      <h5 className="font-semibold text-sm mb-2 text-zinc-700">
                        📋 Achados ({foto.analiseGemini!.achados.length})
                      </h5>
                      <div className="space-y-2">
                        {foto.analiseGemini!.achados.map((achado, i) => (
                          <div
                            key={i}
                            className="bg-white p-3 rounded border-l-4 border-[#D4AF37]"
                          >
                            <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                              <div>
                                <p className="text-zinc-600">Ambiente</p>
                                <p className="font-semibold">{achado.ambiente_setor}</p>
                              </div>
                              <div>
                                <p className="text-zinc-600">Patologia</p>
                                <p className="font-semibold">{achado.titulo_patologia}</p>
                              </div>
                            </div>
                            <p className="text-xs text-zinc-700">
                              {achado.descricao_tecnica}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* RESUMO */}
                  <div className="bg-blue-50 p-3 rounded border border-blue-200">
                    <p className="text-xs text-blue-900">
                      {foto.analiseGemini!.resumo_executivo}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ESTADO VAZIO */}
      {fotos.length === 0 && (
        <div className="text-center py-8 text-zinc-500">
          <p className="text-sm">Nenhuma foto adicionada ainda.</p>
          <p className="text-xs text-zinc-400 mt-1">Use o upload acima para começar.</p>
        </div>
      )}

      {/* BOTÃO PRÓXIMO */}
      {fotos.length > 0 && (
        <div className="flex justify-end gap-2 pt-4 border-t border-zinc-200">
          <button
            onClick={handleNext}
            disabled={!podeAvancar}
            className="px-6 py-2 bg-[#D4AF37] text-black rounded-lg font-semibold hover:bg-[#B8962E] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Próximo ({fotosAnalisadasArray.length}/{totalFotos} analisadas)
          </button>
        </div>
      )}
    </div>
  );
}