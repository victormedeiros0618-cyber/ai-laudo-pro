import { useRef, useState } from 'react';
import { Upload, X } from 'lucide-react';
import { useFotoManager } from '@/hooks/useFotoManager';
import { toast } from 'sonner';

interface FotoUploadBProps {
    tipoLaudo: string;
    descricao?: string;
}

export function FotoUploadB({ tipoLaudo, descricao }: FotoUploadBProps) {
    const inputRef = useRef<HTMLInputElement>(null);
    const [dragActive, setDragActive] = useState(false);

    // ✅ HOOKS
    const { adicionarFoto } = useFotoManager();

    // ============ PROCESSAR ARQUIVO ============
    const processarArquivo = (file: File) => {
        // ✅ VALIDAR ARQUIVO
        if (!file.type.startsWith('image/')) {
            toast.error('Apenas imagens são permitidas');
            return;
        }

        // ✅ VALIDAR TAMANHO (máx 10MB)
        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
            toast.error('Arquivo muito grande (máx 10MB)');
            return;
        }

        // ✅ ADICIONAR FOTO À LISTA (SEM ANÁLISE AUTOMÁTICA)
        const novaFoto = adicionarFoto(file);
        if (!novaFoto) {
            toast.error('Erro ao adicionar foto');
            return;
        }

        console.log('🟢 Foto adicionada:', novaFoto.id);
        toast.success('Foto adicionada à fila');
    };

    // ============ HANDLE FILE INPUT ============
    const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.currentTarget.files;
        if (!files) return;

        for (let i = 0; i < files.length; i++) {
            processarArquivo(files[i]);
        }

        // ✅ LIMPAR INPUT
        if (inputRef.current) {
            inputRef.current.value = '';
        }
    };

    // ============ HANDLE DRAG & DROP ============
    const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();

        if (e.type === 'dragenter' || e.type === 'dragover') {
            setDragActive(true);
        } else if (e.type === 'dragleave') {
            setDragActive(false);
        }
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);

        const files = e.dataTransfer.files;
        if (!files) return;

        for (let i = 0; i < files.length; i++) {
            processarArquivo(files[i]);
        }
    };

    // ============ RENDER ============
    return (
        <div className="space-y-4">
            {/* ÁREA DE UPLOAD */}
            <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${dragActive
                        ? 'border-[#D4AF37] bg-yellow-50'
                        : 'border-zinc-300 bg-zinc-50 hover:border-[#D4AF37]'
                    }`}
            >
                <input
                    ref={inputRef}
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleFileInput}
                    className="hidden"
                />

                <div className="flex flex-col items-center gap-2">
                    <Upload size={32} className="text-[#D4AF37]" />
                    <div>
                        <p className="text-sm font-semibold text-zinc-900">
                            Arraste fotos aqui ou clique para selecionar
                        </p>
                        <p className="text-xs text-zinc-600 mt-1">
                            Formatos: JPG, PNG, WebP (máx 10MB cada)
                        </p>
                    </div>
                </div>

                <button
                    onClick={() => inputRef.current?.click()}
                    className="mt-4 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-semibold hover:bg-[#B8962E] transition-colors"
                >
                    Selecionar Fotos
                </button>
            </div>

            {/* NOTA IMPORTANTE */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-900">
                    💡 <strong>Dica:</strong> Adicione todas as fotos primeiro, depois clique em "Analisar Todas" para processar em lotes e economizar requisições.
                </p>
            </div>
        </div>
    );
}