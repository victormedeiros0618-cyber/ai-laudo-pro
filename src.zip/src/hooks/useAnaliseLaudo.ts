import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import type { RelatorioIA } from '@/types';

interface BatchFoto {
    id: string;
    imageBase64: string;
}

interface BatchResponse {
    resultados: Array<{
        fotoId: string;
        analise?: RelatorioIA;
        erro?: string;
    }>;
    resumo: {
        total: number;
        sucesso: number;
        erro: number;
        tempo_ms: number;
    };
}

export function useAnaliseLaudo() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // ============ ANALISAR LOTE DE FOTOS ============
    const analisarLote = useCallback(
        async (
            fotos: Array<{ id: string; file: File | Blob }>,
            tipoLaudo: string,
            descricao?: string
        ): Promise<Map<string, RelatorioIA | null>> => {
            try {
                setLoading(true);
                setError(null);

                if (fotos.length === 0) {
                    throw new Error('Nenhuma foto para analisar');
                }

                console.log(`🟢 Iniciando análise em lote de ${fotos.length} fotos...`);
                toast.loading(`Analisando ${fotos.length} fotos...`);

                // ✅ CONVERTER FOTOS PARA BASE64
                const fotosBase64: BatchFoto[] = [];

                for (const foto of fotos) {
                    const base64 = await new Promise<string>((resolve, reject) => {
                        const reader = new FileReader();

                        reader.onload = () => {
                            try {
                                const result = reader.result as string;
                                const base64String = result.includes(',')
                                    ? result.split(',')[1]
                                    : result;
                                resolve(base64String);
                            } catch (err) {
                                reject(err);
                            }
                        };

                        reader.onerror = () => {
                            reject(new Error('Erro ao ler arquivo'));
                        };

                        reader.readAsDataURL(foto.file);
                    });

                    fotosBase64.push({
                        id: foto.id,
                        imageBase64: base64,
                    });
                }

                console.log(`🟢 ${fotosBase64.length} fotos convertidas para base64`);

                // ✅ OBTER VARIÁVEIS DE AMBIENTE
                const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
                const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

                if (!supabaseUrl || !supabaseAnonKey) {
                    throw new Error('Variáveis de ambiente Supabase não configuradas');
                }

                console.log('🟢 Chamando Edge Function batch-analyze...');

                // ✅ CHAMAR EDGE FUNCTION BATCH-ANALYZE
                const response = await fetch(
                    `${supabaseUrl}/functions/v1/batch-analyze`,
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${supabaseAnonKey}`,
                        },
                        body: JSON.stringify({
                            fotos: fotosBase64,
                            tipoLaudo,
                            descricao,
                        }),
                    }
                );

                console.log('🟢 Resposta recebida:', response.status);

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    console.error('🔴 Erro da Edge Function:', errorData);
                    throw new Error(
                        errorData.details || `Erro ${response.status}: ${response.statusText}`
                    );
                }

                const batchResult: BatchResponse = await response.json();

                console.log(`🟢 Análise em lote concluída:`, batchResult.resumo);

                // ✅ MAPEAR RESULTADOS POR FOTO ID
                const resultadosMap = new Map<string, RelatorioIA | null>();

                batchResult.resultados.forEach((resultado) => {
                    if (resultado.analise) {
                        resultadosMap.set(resultado.fotoId, resultado.analise);
                        console.log(`✅ Foto ${resultado.fotoId}: ${resultado.analise.achados.length} achados`);
                    } else {
                        resultadosMap.set(resultado.fotoId, null);
                        console.error(`🔴 Foto ${resultado.fotoId}: ${resultado.erro}`);
                    }
                });

                toast.success(`Análise concluída! ${batchResult.resumo.sucesso}/${batchResult.resumo.total} fotos analisadas`);

                return resultadosMap;
            } catch (err) {
                const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido';
                console.error('🔴 Erro na análise em lote:', errorMessage);
                setError(errorMessage);
                toast.error(`Erro ao analisar fotos: ${errorMessage}`);
                return new Map();
            } finally {
                setLoading(false);
            }
        },
        []
    );

    return {
        loading,
        error,
        analisarLote,
    };
}