import { createContext, useContext, useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

interface AuthContextType {
    user: any;
    loading: boolean;
    signIn: (email: string, password: string) => Promise<void>;
    signUp: (email: string, password: string, fullName: string) => Promise<void>;
    signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const subscriptionRef = useRef<any>(null);
    const isSigningOutRef = useRef(false);

    useEffect(() => {
        console.log('🔵 AuthProvider: Inicializando...');

        // Carregar sessão inicial
        supabase.auth.getSession().then(({ data: { session } }) => {
            console.log('🔵 AuthProvider: getSession retornou:', session?.user?.email || 'null');
            setUser(session?.user ?? null);
            setLoading(false);
        });

        // Listener para mudanças de autenticação
        if (!subscriptionRef.current) {
            subscriptionRef.current = supabase.auth.onAuthStateChange((_event, session) => {
                console.log('🔵 AuthProvider: onAuthStateChange evento:', _event);
                console.log('🔵 AuthProvider: onAuthStateChange sessão:', session?.user?.email || 'null');

                // Se estamos no meio de um signOut, não atualize o estado
                if (isSigningOutRef.current) {
                    console.log('🟡 AuthProvider: Ignorando atualização durante signOut');
                    return;
                }

                setUser(session?.user ?? null);
                setLoading(false);
            });
        }

        return () => {
            if (subscriptionRef.current) {
                subscriptionRef.current.data.subscription.unsubscribe();
                subscriptionRef.current = null;
            }
        };
    }, []);

    const signIn = async (email: string, password: string) => {
        console.log('🔵 AuthProvider: signIn chamado para:', email);
        setLoading(true);
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
            console.error('🔴 AuthProvider: signIn erro:', error);
            setLoading(false);
            throw error;
        }
        console.log('🟢 AuthProvider: signIn sucesso');
    };

    const signUp = async (email: string, password: string, fullName: string) => {
        setLoading(true);
        const { error } = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: { full_name: fullName },
            },
        });
        if (error) throw error;
    };

    const signOut = async () => {
        console.log('🔵 AuthProvider: signOut chamado');
        isSigningOutRef.current = true;
        setLoading(true);

        // Limpar estado ANTES de fazer signOut
        setUser(null);

        // CRÍTICO: Remover sessão do localStorage ANTES de chamar signOut
        try {
            // Remover todas as chaves do Supabase do localStorage
            const keys = Object.keys(localStorage);
            keys.forEach(key => {
                if (key.includes('supabase') || key.includes('auth')) {
                    console.log('🟡 AuthProvider: Removendo localStorage key:', key);
                    localStorage.removeItem(key);
                }
            });
        } catch (err) {
            console.error('🔴 AuthProvider: Erro ao limpar localStorage:', err);
        }

        // Agora fazer o signOut no Supabase
        const { error } = await supabase.auth.signOut();

        if (error) {
            console.error('🔴 AuthProvider: signOut erro:', error);
            isSigningOutRef.current = false;
            setLoading(false);
            throw error;
        }

        console.log('🟢 AuthProvider: signOut sucesso');
        setLoading(false);
        isSigningOutRef.current = false;

        // Redirecionar para login
        navigate('/login', { replace: true });
    };

    return (
        <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}