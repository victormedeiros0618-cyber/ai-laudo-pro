import { useEffect, useState } from 'react';

export type DeviceType = 'desktop' | 'mobile' | 'tablet';

export const useDeviceDetection = () => {
    const [device, setDevice] = useState<DeviceType>('desktop');

    useEffect(() => {
        const detectDevice = () => {
            const userAgent = navigator.userAgent.toLowerCase();

            // Detectar tablet (antes de mobile, pois iPad tem "mobile" no UA)
            if (/ipad|android(?!.*mobile)/.test(userAgent)) {
                setDevice('tablet');
                return;
            }

            // Detectar mobile
            if (/iphone|ipod|android|windows phone/.test(userAgent)) {
                setDevice('mobile');
                return;
            }

            // Desktop
            setDevice('desktop');
        };

        detectDevice();

        // Detectar mudanças de orientação
        window.addEventListener('orientationchange', detectDevice);
        window.addEventListener('resize', detectDevice);

        return () => {
            window.removeEventListener('orientationchange', detectDevice);
            window.removeEventListener('resize', detectDevice);
        };
    }, []);

    return { device, isMobile: device === 'mobile', isTablet: device === 'tablet', isDesktop: device === 'desktop' };
};