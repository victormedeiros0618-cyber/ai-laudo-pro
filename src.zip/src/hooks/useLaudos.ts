import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './useAuth';
import { toast } from 'sonner';
import type { RelatorioIA } from '@/types';

export interface Laudo {
    id: string;
    user_id: string;
    titulo?: string;
    cliente: string;
    endereco?: string;
    gravidade?: string;
    tipo_vistoria: string;
    responsavel?: string;
    data_vistoria: string;
    conteudo_json: RelatorioIA;
    pdf_url?: string;
    status: 'draft' | 'finalizado' | 'assinado';
    created_at: string;
    updated_at: string;
}

interface CreateLaudoInput {
    cliente: string;
    tipo_vistoria: string;
    data_vistoria: string;
    endereco?: string;
    responsavel?: string;
    titulo?: string;
    conteudo_json: RelatorioIA;
}

interface UpdateLaudoInput {
    titulo?: string;
    endereco?: string;
    responsavel?: string;
    conteudo_json?: RelatorioIA;
    status?: 'draft' | 'finalizado' | 'assinado';
    pdf_url?: string;
}

export function useLaudos() {
    const { user } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // ============ LISTAR LAUDOS ============
    const listarLaudos = useCallback(async () => {
        if (!user) {
            setError('Usuário não autenticado');
            return [];
        }

        try {
            setLoading(true);
            setError(null);

            const { data, error: err } = await supabase
                .from('laudos')
                .select('*')
                .eq('user_id', user.id)
                .order('created_at', { ascending: false });

            if (err) {
                console.error('🔴 Erro ao listar laudos:', err);
                setError(err.message);
                toast.error('Erro ao carregar laudos');
                return [];
            }

            console.log('🟢 Laudos carregados:', data?.length);
            return (data as Laudo[]) || [];
        } catch (err) {
            console.error('🔴 Erro:', err);
            setError('Erro ao listar laudos');
            return [];
        } finally {
            setLoading(false);
        }
    }, [user]);

    // ============ OBTER LAUDO POR ID ============
    const obterLaudo = useCallback(async (laudoId: string) => {
        if (!user) {
            setError('Usuário não autenticado');
            return null;
        }

        try {
            setLoading(true);
            setError(null);

            const { data, error: err } = await supabase
                .from('laudos')
                .select('*')
                .eq('id', laudoId)
                .eq('user_id', user.id)
                .single();

            if (err) {
                console.error('🔴 Erro ao obter laudo:', err);
                setError(err.message);
                return null;
            }

            console.log('🟢 Laudo obtido:', laudoId);
            return (data as Laudo) || null;
        } catch (err) {
            console.error('🔴 Erro:', err);
            setError('Erro ao obter laudo');
            return null;
        } finally {
            setLoading(false);
        }
    }, [user]);

    // ============ CRIAR LAUDO ============
    const criarLaudo = useCallback(async (input: CreateLaudoInput) => {
        if (!user) {
            setError('Usuário não autenticado');
            toast.error('Você precisa estar autenticado');
            return null;
        }

        // Validação
        if (!input.cliente || !input.tipo_vistoria) {
            setError('Cliente e tipo de vistoria são obrigatórios');
            toast.error('Preencha os campos obrigatórios');
            return null;
        }

        try {
            setLoading(true);
            setError(null);

            const { data, error: err } = await supabase
                .from('laudos')
                .insert([
                    {
                        user_id: user.id,
                        cliente: input.cliente,
                        tipo_vistoria: input.tipo_vistoria,
                        data_vistoria: input.data_vistoria,
                        endereco: input.endereco || null,
                        responsavel: input.responsavel || null,
                        titulo: input.titulo || null,
                        conteudo_json: input.conteudo_json,
                        status: 'draft',
                    },
                ])
                .select()
                .single();

            if (err) {
                console.error('🔴 Erro ao criar laudo:', err);
                setError(err.message);
                toast.error('Erro ao criar laudo');
                return null;
            }

            console.log('🟢 Laudo criado:', data?.id);
            toast.success('Laudo criado com sucesso!');
            return (data as Laudo) || null;
        } catch (err) {
            console.error('🔴 Erro:', err);
            setError('Erro ao criar laudo');
            toast.error('Erro ao criar laudo');
            return null;
        } finally {
            setLoading(false);
        }
    }, [user]);

    // ============ ATUALIZAR LAUDO ============
    const atualizarLaudo = useCallback(
        async (laudoId: string, input: UpdateLaudoInput) => {
            if (!user) {
                setError('Usuário não autenticado');
                toast.error('Você precisa estar autenticado');
                return null;
            }

            try {
                setLoading(true);
                setError(null);

                const { data, error: err } = await supabase
                    .from('laudos')
                    .update({
                        ...input,
                        updated_at: new Date().toISOString(),
                    })
                    .eq('id', laudoId)
                    .eq('user_id', user.id)
                    .select()
                    .single();

                if (err) {
                    console.error('🔴 Erro ao atualizar laudo:', err);
                    setError(err.message);
                    toast.error('Erro ao atualizar laudo');
                    return null;
                }

                console.log('🟢 Laudo atualizado:', laudoId);
                toast.success('Laudo atualizado com sucesso!');
                return (data as Laudo) || null;
            } catch (err) {
                console.error('🔴 Erro:', err);
                setError('Erro ao atualizar laudo');
                toast.error('Erro ao atualizar laudo');
                return null;
            } finally {
                setLoading(false);
            }
        },
        [user]
    );

    // ============ DELETAR LAUDO ============
    const deletarLaudo = useCallback(
        async (laudoId: string) => {
            if (!user) {
                setError('Usuário não autenticado');
                toast.error('Você precisa estar autenticado');
                return false;
            }

            try {
                setLoading(true);
                setError(null);

                const { error: err } = await supabase
                    .from('laudos')
                    .delete()
                    .eq('id', laudoId)
                    .eq('user_id', user.id);

                if (err) {
                    console.error('🔴 Erro ao deletar laudo:', err);
                    setError(err.message);
                    toast.error('Erro ao deletar laudo');
                    return false;
                }

                console.log('🟢 Laudo deletado:', laudoId);
                toast.success('Laudo deletado com sucesso!');
                return true;
            } catch (err) {
                console.error('🔴 Erro:', err);
                setError('Erro ao deletar laudo');
                toast.error('Erro ao deletar laudo');
                return false;
            } finally {
                setLoading(false);
            }
        },
        [user]
    );

    // ============ GERAR PDF ============
    const gerarPDF = useCallback(
        async (laudoId: string, pdfUrl: string) => {
            if (!user) {
                setError('Usuário não autenticado');
                return false;
            }

            try {
                setLoading(true);
                setError(null);

                const { error: err } = await supabase
                    .from('laudos')
                    .update({
                        pdf_url: pdfUrl,
                        status: 'finalizado',
                        updated_at: new Date().toISOString(),
                    })
                    .eq('id', laudoId)
                    .eq('user_id', user.id);

                if (err) {
                    console.error('🔴 Erro ao salvar PDF:', err);
                    setError(err.message);
                    toast.error('Erro ao salvar PDF');
                    return false;
                }

                console.log('🟢 PDF salvo:', laudoId);
                toast.success('PDF gerado com sucesso!');
                return true;
            } catch (err) {
                console.error('🔴 Erro:', err);
                setError('Erro ao salvar PDF');
                toast.error('Erro ao salvar PDF');
                return false;
            } finally {
                setLoading(false);
            }
        },
        [user]
    );

    return {
        loading,
        error,
        listarLaudos,
        obterLaudo,
        criarLaudo,
        atualizarLaudo,
        deletarLaudo,
        gerarPDF,
    };
}