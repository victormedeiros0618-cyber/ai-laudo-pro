export const INSTRUCOES_TIPO_LAUDO = {
    "Perícia Judicial": `FOCO PERICIAL (NBR 13752): Estabeleça OBRIGATORIAMENTE o NEXO CAUSAL para cada anomalia. Identifique tecnicamente a causa raiz (ex: recalque, infiltração, vibração) e documente a relação com eventuais obras vizinhas.`,

    "Cautelar de Vizinhança": `FOCO CAUTELAR DE VIZINHANÇA (NBR 13752): Documente o estado ATUAL antes de eventuais alterações. Para cada anomalia, estabeleça nexo causal com possível responsabilidade de obra vizinha. Priorize evidências fotográficas.`,

    "Vistoria Técnica": `FOCO VISTORIA TÉCNICA (IBAPE): Constate o estado de conservação atual. Descreva condições gerais, materiais e sistemas observados. Registre patologias APENAS quando existentes — não force identificação de problemas inexistentes.`,

    "Inspeção Predial": `FOCO INSPEÇÃO PREDIAL (NBR 16747): Classifique o estado de conservação e categorize falhas como: manutenção, uso ou causas endógenas. Avalie a perda de desempenho funcional sem superdimensionar achados.`,
};

export const getInstrucaoExtra = (tipoLaudo: string): string => {
    return INSTRUCOES_TIPO_LAUDO[tipoLaudo as keyof typeof INSTRUCOES_TIPO_LAUDO] || "";
};