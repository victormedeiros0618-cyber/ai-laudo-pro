import { jsPDF } from 'jspdf';
import type { AchadoTecnico, RelatorioIA } from '@/types';

interface GerarPDFParams {
    achados: AchadoTecnico[];
    formData: Record<string, string>;
    fotos: string[];
    iaResult: RelatorioIA;
}

export const gerarPDFOficial = async ({
    achados,
    formData,
    fotos,
    iaResult,
}: GerarPDFParams): Promise<void> => {
    try {
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        let yPosition = 20;

        // Cores
        const primaryColor: [number, number, number] = [212, 175, 55]; // #D4AF37
        const darkColor: [number, number, number] = [10, 10, 10]; // #0A0A0A
        const lightColor: [number, number, number] = [245, 245, 245]; // #F5F5F5

        // HEADER
        doc.setFillColor(...primaryColor);
        doc.rect(0, 0, pageWidth, 30, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        doc.text('LAUDO TÉCNICO', 20, 20);

        // INFORMAÇÕES BÁSICAS
        yPosition = 45;
        doc.setTextColor(...darkColor);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');

        const infoFields = [
            { label: 'Tipo de Laudo:', value: formData.tipoLaudo || 'N/A' },
            { label: 'Responsável:', value: formData.responsavel || 'N/A' },
            { label: 'Data da Vistoria:', value: formData.dataVistoria || 'N/A' },
            { label: 'Endereço:', value: formData.endereco || 'N/A' },
        ];

        infoFields.forEach(({ label, value }) => {
            doc.setFont('helvetica', 'bold');
            doc.text(label, 20, yPosition);
            doc.setFont('helvetica', 'normal');
            doc.text(value, 60, yPosition);
            yPosition += 8;
        });

        // RESUMO EXECUTIVO
        yPosition += 10;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(12);
        doc.text('RESUMO EXECUTIVO', 20, yPosition);
        yPosition += 8;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        const resumoLines = doc.splitTextToSize(iaResult.resumo_executivo, pageWidth - 40);
        doc.text(resumoLines, 20, yPosition);
        yPosition += resumoLines.length * 5 + 10;

        // ACHADOS TÉCNICOS
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(12);
        doc.text('ACHADOS TÉCNICOS', 20, yPosition);
        yPosition += 10;

        achados.forEach((achado, index) => {
            // Verificar se precisa de nova página
            if (yPosition > pageHeight - 40) {
                doc.addPage();
                yPosition = 20;
            }

            // Cabeçalho do achado
            doc.setFillColor(...lightColor);
            doc.rect(20, yPosition - 5, pageWidth - 40, 8, 'F');
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(10);
            doc.text(`${index + 1}. ${achado.titulo_patologia}`, 22, yPosition);
            yPosition += 10;

            // Detalhes
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(9);

            const detalhes = [
                `Ambiente: ${achado.ambiente_setor}`,
                `Gravidade: ${achado.gravidade.toUpperCase()}`,
                `GUT Score: ${achado.gut_score}`,
                `Custo Estimado: ${achado.estimativa_custo}`,
                `Norma NBR: ${achado.norma_nbr_relacionada}`,
            ];

            detalhes.forEach((detalhe) => {
                doc.text(detalhe, 22, yPosition);
                yPosition += 5;
            });

            // Descrição técnica
            yPosition += 3;
            doc.setFont('helvetica', 'bold');
            doc.text('Descrição Técnica:', 22, yPosition);
            yPosition += 4;

            doc.setFont('helvetica', 'normal');
            const descLines = doc.splitTextToSize(achado.descricao_tecnica, pageWidth - 44);
            doc.text(descLines, 22, yPosition);
            yPosition += descLines.length * 4 + 3;

            // Recomendação
            doc.setFont('helvetica', 'bold');
            doc.text('Recomendação:', 22, yPosition);
            yPosition += 4;

            doc.setFont('helvetica', 'normal');
            const recLines = doc.splitTextToSize(achado.recomendacao_intervencao, pageWidth - 44);
            doc.text(recLines, 22, yPosition);
            yPosition += recLines.length * 4 + 8;
        });

        // FOTOS
        if (fotos.length > 0) {
            doc.addPage();
            yPosition = 20;

            doc.setFont('helvetica', 'bold');
            doc.setFontSize(12);
            doc.text('EVIDÊNCIAS FOTOGRÁFICAS', 20, yPosition);
            yPosition += 15;

            fotos.slice(0, 4).forEach((foto, index) => {
                if (yPosition > pageHeight - 80) {
                    doc.addPage();
                    yPosition = 20;
                }

                doc.addImage(foto, 'JPEG', 20, yPosition, 170, 100);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(9);
                doc.text(`Foto ${index + 1}`, 20, yPosition + 105);
                yPosition += 115;
            });
        }

        // RODAPÉ
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text(
            `Gerado por Engenharia AI em ${new Date().toLocaleDateString('pt-BR')}`,
            20,
            pageHeight - 10
        );

        // Download
        doc.save(`laudo-${formData.cliente || 'tecnico'}.pdf`);
        console.log('🟢 PDF gerado com sucesso');
    } catch (err) {
        console.error('🔴 Erro ao gerar PDF:', err);
        throw err;
    }
};