import { useState, useEffect, useRef } from 'react';
import { ChevronDown, ChevronRight, Plus, Trash2, Upload, Check, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'react-router-dom';
import type { Vistoriador } from '@/types';

interface AccordionSectionProps {
  title: string;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}

function AccordionSection({ title, isOpen, onToggle, children }: AccordionSectionProps) {
  return (
    <div
      className="rounded-[var(--radius-md)] overflow-hidden"
      style={{ border: '1px solid var(--color-border)', background: 'var(--color-surface)' }}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-5 py-4 text-left hover:opacity-80 transition-opacity"
      >
        <span className="font-display text-sm font-semibold" style={{ color: 'var(--color-text-primary)' }}>
          {title}
        </span>
        {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
      </button>
      {isOpen && (
        <div className="px-5 pb-5" style={{ borderTop: '1px solid var(--color-border)' }}>
          {children}
        </div>
      )}
    </div>
  );
}

const inputStyle = {
  border: '1px solid var(--color-border)',
  background: 'var(--color-surface)',
  color: 'var(--color-text-primary)',
};

export default function Configuracoes() {
  const { user } = useAuth();
  const location = useLocation();

  // Estados
  const [activeAccordion, setActiveAccordion] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  // Configurações
  const [corPrimaria, setCorPrimaria] = useState('#005f73');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [assinaturaUrl, setAssinaturaUrl] = useState<string | null>(null);
  const [vistoriadores, setVistoriadores] = useState<Vistoriador[]>([]);
  const [novoVist, setNovoVist] = useState({ nome: '', cargo: '', crea_cau: '' });
  const [metodologia, setMetodologia] = useState('');
  const [conclusao, setConclusao] = useState('');
  const [deleteModal, setDeleteModal] = useState<string | null>(null);

  // Upload preview
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [assinaturaPreview, setAssinaturaPreview] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const assinaturaInputRef = useRef<HTMLInputElement>(null);

  // Auto-save timer
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);

  // ============ CARREGAMENTO INICIAL ============
  useEffect(() => {
    if (!user) return;

    const loadConfiguracoes = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('configuracoes')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (error && error.code !== 'PGRST116') {
          console.error('Erro ao carregar configurações:', error);
          toast.error('Erro ao carregar configurações');
          return;
        }

        if (data) {
          setCorPrimaria(data.cor_primaria || '#005f73');
          setLogoUrl(data.logo_url || null);
          setAssinaturaUrl(data.assinatura_url || null);
          setVistoriadores(data.vistoriadores || []);
          setMetodologia(data.texto_metodologia || '');
          setConclusao(data.texto_conclusao || '');
        }
      } catch (err) {
        console.error('Erro:', err);
        toast.error('Erro ao carregar configurações');
      } finally {
        setLoading(false);
      }
    };

    loadConfiguracoes();
  }, [user]);

  // ============ CLEANUP DO TIMER ============
  // ✅ ADICIONAR AQUI (DENTRO DA FUNÇÃO):
  useEffect(() => {
    return () => {
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
      }
    };
  }, []);

  // ============ ABRIR EXPAND VIA QUERY PARAMS ============
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const section = searchParams.get('section');
    if (section) {
      setActiveAccordion(section);
      setTimeout(() => {
        const element = document.querySelector(`[data-section="${section}"]`);
        element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }, [location.search]);

  // ============ AUTO-SAVE EM TEMPO REAL ============
  const autoSave = async (data: any) => {
    if (!user) {
      console.warn('🟡 Auto-save: Usuário não autenticado');
      return;
    }

    // ✅ ADICIONAR ESTA VALIDAÇÃO:
    if (isSaving) {
      console.warn('🟡 Auto-save já em progresso, ignorando...');
      return;
    }

    try {
      setIsSaving(true);
      setSaveStatus('saving');

      const { error } = await supabase
        .from('configuracoes')
        .upsert({
          user_id: user.id,
          ...data,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'user_id',
        });

      if (error) {
        console.error('🔴 Erro ao salvar:', error);
        setSaveStatus('error');
        toast.error(`Erro ao salvar: ${error.message}`);

        // Retry automático após 3s
        setTimeout(() => {
          setIsSaving(false);
          autoSave(data);
        }, 3000);
        return;
      }

      setSaveStatus('saved');
      setTimeout(() => {
        setSaveStatus('idle');
        setIsSaving(false);
      }, 2000);
    } catch (err) {
      console.error('Erro:', err);
      setSaveStatus('error');
      toast.error('Erro ao salvar configurações');
      setIsSaving(false);
    }
  };

  // ============ HANDLERS COM AUTO-SAVE ============
  const handleCorPrimariaChange = (newColor: string) => {
    setCorPrimaria(newColor);

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);

    saveTimerRef.current = setTimeout(() => {
      autoSave({ cor_primaria: newColor });
    }, 1000);
  };

  const handleMetodologiaChange = (text: string) => {
    setMetodologia(text);

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      autoSave({ texto_metodologia: text });
    }, 1000);
  };

  const handleConclusaoChange = (text: string) => {
    setConclusao(text);

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      autoSave({ texto_conclusao: text });
    }, 1000);
  };

  // ============ UPLOAD DE LOGO ============
  const handleLogoUpload = async (file: File) => {
    if (!user) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Logo deve ter no máximo 5MB');
      return;
    }

    try {
      setIsSaving(true);

      const reader = new FileReader();
      reader.onload = (e) => setLogoPreview(e.target?.result as string);
      reader.readAsDataURL(file);

      const fileName = `${user.id}/logo-${Date.now()}`;
      const { data, error } = await supabase.storage
        .from('configuracoes')
        .upload(fileName, file, { upsert: true });

      if (error) {
        toast.error('Erro ao fazer upload do logo');
        return;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('configuracoes')
        .getPublicUrl(fileName);

      setLogoUrl(publicUrl);

      await autoSave({ logo_url: publicUrl });
      toast.success('Logo enviado com sucesso!');
    } catch (err) {
      console.error('Erro:', err);
      toast.error('Erro ao fazer upload do logo');
    } finally {
      setIsSaving(false);
    }
  };

  // ============ UPLOAD DE ASSINATURA ============
  const handleAssinaturaUpload = async (file: File) => {
    if (!user) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Assinatura deve ter no máximo 5MB');
      return;
    }

    try {
      setIsSaving(true);

      const reader = new FileReader();
      reader.onload = (e) => setAssinaturaPreview(e.target?.result as string);
      reader.readAsDataURL(file);

      const fileName = `${user.id}/assinatura-${Date.now()}`;
      const { data, error } = await supabase.storage
        .from('configuracoes')
        .upload(fileName, file, { upsert: true });

      if (error) {
        toast.error('Erro ao fazer upload da assinatura');
        return;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('configuracoes')
        .getPublicUrl(fileName);

      setAssinaturaUrl(publicUrl);

      await autoSave({ assinatura_url: publicUrl });
      toast.success('Assinatura enviada com sucesso!');
    } catch (err) {
      console.error('Erro:', err);
      toast.error('Erro ao fazer upload da assinatura');
    } finally {
      setIsSaving(false);
    }
  };

  // ============ VISTORIADORES COM AUTO-SAVE ============
  const addVistoriador = async () => {
    if (!novoVist.nome || !novoVist.cargo || !novoVist.crea_cau) {
      toast.error('Preencha todos os campos');
      return;
    }

    try {
      const novoVistoriadorObj = { ...novoVist, id: Date.now().toString() };
      const novaLista = [...vistoriadores, novoVistoriadorObj];

      setVistoriadores(novaLista);
      setNovoVist({ nome: '', cargo: '', crea_cau: '' });

      await autoSave({ vistoriadores: novaLista });
      toast.success('Vistoriador adicionado e salvo!');
    } catch (err) {
      console.error('Erro:', err);
      toast.error('Erro ao adicionar vistoriador');
    }
  };

  const removeVistoriador = async (id: string) => {
    try {
      const novaLista = vistoriadores.filter(v => v.id !== id);
      setVistoriadores(novaLista);
      setDeleteModal(null);

      await autoSave({ vistoriadores: novaLista });
      toast.success('Vistoriador removido!');
    } catch (err) {
      console.error('Erro:', err);
      toast.error('Erro ao remover vistoriador');
    }
  };

  const toggle = (key: string) => setActiveAccordion(prev => (prev === key ? null : key));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#D4AF37] mx-auto mb-2"></div>
          <p className="text-white text-sm">Carregando configurações...</p>
        </div>
      </div>
    );
  }

  // ============ RENDER ============
  return (
    <div className="space-y-4">
      {/* Header com Status de Save */}
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
          Configurações
        </h1>

        {/* Indicador de Status */}
        <div className="flex items-center gap-2 text-xs">
          {saveStatus === 'saving' && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-full" style={{ background: 'var(--color-primary)', color: 'white' }}>
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-current"></div>
              Salvando...
            </div>
          )}
          {saveStatus === 'saved' && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-full" style={{ background: '#10b981', color: 'white' }}>
              <Check size={14} />
              Salvo
            </div>
          )}
          {saveStatus === 'error' && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-full" style={{ background: '#ef4444', color: 'white' }}>
              <AlertCircle size={14} />
              Erro ao salvar
            </div>
          )}
        </div>
      </div>

      {/* Identidade Visual */}
      <div data-section="identidade">
        <AccordionSection title="Identidade Visual" isOpen={activeAccordion === 'identidade'} onToggle={() => toggle('identidade')}>
          <div className="pt-4 space-y-4">
            {/* Logo */}
            <div>
              <label className="block text-xs font-display font-medium mb-2" style={{ color: 'var(--color-text-secondary)' }}>
                Logo do Escritório
              </label>

              {logoPreview || logoUrl ? (
                <div className="space-y-2">
                  <img
                    src={logoPreview || logoUrl}
                    alt="Logo preview"
                    className="h-20 object-contain rounded-[var(--radius-md)]"
                  />
                  <button
                    onClick={() => logoInputRef.current?.click()}
                    className="text-xs px-3 py-1 rounded-[var(--radius-sm)]"
                    style={{ background: 'var(--color-primary)', color: 'white' }}
                    disabled={isSaving}
                  >
                    {isSaving ? 'Enviando...' : 'Alterar Logo'}
                  </button>
                </div>
              ) : (
                <div
                  className="rounded-[var(--radius-md)] p-8 text-center cursor-pointer hover:opacity-80 transition-opacity"
                  style={{ border: '2px dashed var(--color-border)', background: 'var(--color-bg)' }}
                  onClick={() => logoInputRef.current?.click()}
                >
                  <Upload size={24} className="mx-auto mb-2" style={{ color: 'var(--color-text-muted)' }} />
                  <p className="text-xs font-body" style={{ color: 'var(--color-text-muted)' }}>
                    Clique para enviar logo (máx 5MB)
                  </p>
                </div>
              )}

              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0])}
                className="hidden"
              />
            </div>

            {/* Cor Primária */}
            <div>
              <label className="block text-xs font-display font-medium mb-2" style={{ color: 'var(--color-text-secondary)' }}>
                Cor Primária do PDF
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={corPrimaria}
                  onChange={(e) => handleCorPrimariaChange(e.target.value)}
                  className="w-10 h-10 rounded cursor-pointer border-0"
                />
                <input
                  value={corPrimaria}
                  onChange={(e) => handleCorPrimariaChange(e.target.value)}
                  className="px-3 py-2 rounded-[var(--radius-sm)] text-sm font-body w-28"
                  style={inputStyle}
                />
                <div className="h-10 flex-1 rounded-[var(--radius-sm)]" style={{ background: corPrimaria }} />
              </div>
            </div>
          </div>
        </AccordionSection>
      </div>

      {/* Assinatura Digital */}
      <div data-section="assinatura">
        <AccordionSection title="Assinatura Digital" isOpen={activeAccordion === 'assinatura'} onToggle={() => toggle('assinatura')}>
          <div className="pt-4 space-y-3">
            <p className="text-xs font-body" style={{ color: 'var(--color-text-muted)' }}>
              Use fundo transparente para melhor resultado no PDF
            </p>

            {assinaturaPreview || assinaturaUrl ? (
              <div className="space-y-2">
                <img
                  src={assinaturaPreview || assinaturaUrl}
                  alt="Assinatura preview"
                  className="h-20 object-contain rounded-[var(--radius-md)]"
                />
                <button
                  onClick={() => assinaturaInputRef.current?.click()}
                  className="text-xs px-3 py-1 rounded-[var(--radius-sm)]"
                  style={{ background: 'var(--color-primary)', color: 'white' }}
                  disabled={isSaving}
                >
                  {isSaving ? 'Enviando...' : 'Alterar Assinatura'}
                </button>
              </div>
            ) : (
              <div
                className="rounded-[var(--radius-md)] p-8 text-center cursor-pointer hover:opacity-80 transition-opacity"
                style={{ border: '2px dashed var(--color-border)', background: 'var(--color-bg)' }}
                onClick={() => assinaturaInputRef.current?.click()}
              >
                <Upload size={24} className="mx-auto mb-2" style={{ color: 'var(--color-text-muted)' }} />
                <p className="text-xs font-body" style={{ color: 'var(--color-text-muted)' }}>
                  Enviar assinatura PNG (máx 5MB)
                </p>
              </div>
            )}

            <input
              ref={assinaturaInputRef}
              type="file"
              accept="image/png"
              onChange={(e) => e.target.files?.[0] && handleAssinaturaUpload(e.target.files[0])}
              className="hidden"
            />
          </div>
        </AccordionSection>
      </div>

      {/* Vistoriadores */}
      <div data-section="vistoriadores">
        <AccordionSection title="Vistoriadores" isOpen={activeAccordion === 'vistoriadores'} onToggle={() => toggle('vistoriadores')}>
          <div className="pt-4 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <input
                value={novoVist.nome}
                onChange={(e) => setNovoVist((p) => ({ ...p, nome: e.target.value }))}
                placeholder="Nome completo"
                className="px-3 py-2 rounded-[var(--radius-sm)] text-sm font-body"
                style={inputStyle}
              />
              <input
                value={novoVist.cargo}
                onChange={(e) => setNovoVist((p) => ({ ...p, cargo: e.target.value }))}
                placeholder="Cargo"
                className="px-3 py-2 rounded-[var(--radius-sm)] text-sm font-body"
                style={inputStyle}
              />
              <input
                value={novoVist.crea_cau}
                onChange={(e) => setNovoVist((p) => ({ ...p, crea_cau: e.target.value }))}
                placeholder="CREA/CAU"
                className="px-3 py-2 rounded-[var(--radius-sm)] text-sm font-body"
                style={inputStyle}
              />
              <button
                onClick={addVistoriador}
                className="flex items-center justify-center gap-1 px-3 py-2 rounded-[var(--radius-sm)] text-sm font-display font-semibold text-white hover:opacity-90 transition-opacity"
                style={{ background: 'var(--color-primary)' }}
              >
                <Plus size={14} /> Adicionar
              </button>
            </div>

            {vistoriadores.length === 0 ? (
              <p className="text-center text-xs" style={{ color: 'var(--color-text-muted)' }}>
                Nenhum vistoriador adicionado. Clique em "Adicionar" para começar.
              </p>
            ) : (
              <div className="space-y-2">
                {vistoriadores.map((v) => (
                  <div key={v.id} className="flex items-center justify-between px-4 py-3 rounded-[var(--radius-sm)]" style={{ border: '1px solid var(--color-border)' }}>
                    <div className="text-sm font-body" style={{ color: 'var(--color-text-primary)' }}>
                      {v.nome} · {v.cargo} · {v.crea_cau}
                    </div>
                    <button
                      onClick={() => setDeleteModal(v.id)}
                      style={{ color: 'var(--color-danger)' }}
                      className="hover:opacity-70 transition-opacity"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </AccordionSection>
      </div>

      {/* Textos Padrão */}
      <div data-section="textos">
        <AccordionSection title="Textos Padrão do Laudo" isOpen={activeAccordion === 'textos'} onToggle={() => toggle('textos')}>
          <div className="pt-4 space-y-4">
            <div>
              <label className="block text-xs font-display font-medium mb-1.5" style={{ color: 'var(--color-text-secondary)' }}>
                Metodologia da Vistoria
              </label>
              <textarea
                value={metodologia}
                onChange={(e) => handleMetodologiaChange(e.target.value)}
                placeholder="Descreva a metodologia utilizada na vistoria..."
                rows={5}
                disabled={saveStatus === 'saving'}
                className="w-full px-3 py-2.5 rounded-[var(--radius-sm)] text-sm font-body resize-none disabled:opacity-50"
                style={inputStyle}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                {metodologia.length} caracteres
              </p>
            </div>

            <div>
              <label className="block text-xs font-display font-medium mb-1.5" style={{ color: 'var(--color-text-secondary)' }}>
                Conclusão e Isenção de Responsabilidade
              </label>
              <textarea
                value={conclusao}
                onChange={(e) => handleConclusaoChange(e.target.value)}
                placeholder="Texto de conclusão ou isenção padrão..."
                rows={5}
                disabled={saveStatus === 'saving'}
                className="w-full px-3 py-2.5 rounded-[var(--radius-sm)] text-sm font-body resize-none disabled:opacity-50"
                style={inputStyle}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                {conclusao.length} caracteres
              </p>
            </div>

            <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
              💾 As alterações são salvas automaticamente enquanto você digita
            </p>
          </div>
        </AccordionSection>
      </div>

      {/* Delete Modal */}
      {deleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-[var(--radius-lg)] p-6" style={{ background: 'var(--color-surface)', boxShadow: 'var(--shadow-xl)' }}>
            <h3 className="font-display text-sm font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>
              Confirmar exclusão
            </h3>
            <p className="text-xs font-body mb-4" style={{ color: 'var(--color-text-secondary)' }}>
              Deseja remover este vistoriador? Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2 rounded-[var(--radius-sm)] text-xs font-display hover:opacity-80 transition-opacity"
                style={{ border: '1px solid var(--color-border)' }}
              >
                Cancelar
              </button>
              <button
                onClick={() => removeVistoriador(deleteModal)}
                className="px-4 py-2 rounded-[var(--radius-sm)] text-xs font-display font-semibold text-white hover:opacity-90 transition-opacity"
                style={{ background: 'var(--color-danger)' }}
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}