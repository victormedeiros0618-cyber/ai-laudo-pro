import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { StepperAbas } from '@/components/laudo/StepperAbas';
import { AbaInicial } from '@/components/laudo/AbaInicial';
import { EvidenciasTab } from '@/components/laudo/AbaEvidencias';
import { AbaRevisao } from '@/components/laudo/AbaRevisao';
import { useLaudos } from '@/hooks/useLaudos';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { useAuditLog } from '@/hooks/useAuditLog';
import { useAuth } from '@/hooks/useAuth';
import { useFotoManager } from '@/hooks/useFotoManager';
import { toast } from 'sonner';
import type { TipoVistoria, RelatorioIA, AchadoTecnico } from '@/types';

export default function NovoLaudo() {
  const navigate = useNavigate();
  const { user } = useAuth();

  // ============ HOOKS ============
  const { criarLaudo, atualizarLaudo, loading: laudosLoading } = useLaudos();
  const { subscription, carregarSubscription, podecriarLaudo, incrementarLaudosUsados } = useSubscriptions();
  const { registrarCriacaoLaudo, registrarAtualizacaoLaudo } = useAuditLog();

  // ✅ NOVO: Usar useFotoManager para gerenciar fotos
  const { fotos: fotosDoHook } = useFotoManager();

  // ============ ESTADOS ============
  const [activeStep, setActiveStep] = useState(0);
  const [laudoId, setLaudoId] = useState<string | null>(null);
  const [isCreatingLaudo, setIsCreatingLaudo] = useState(false);

  const [formData, setFormData] = useState({
    tipo_vistoria: '' as TipoVistoria | '',
    responsavel: '',
    crea_cau: '',
    data_vistoria: new Date().toISOString().split('T')[0],
    endereco: '',
    cliente: '',
    descricao: '',
    numero_processo: '',
    vara_comarca: '',
    quesitos: '',
  });

  // ✅ REMOVER: const [fotos, setFotos] = useState<string[]>([]);
  // ✅ USAR: fotosDoHook do useFotoManager

  const [iaResult, setIaResult] = useState<RelatorioIA | null>(null);

  // ============ SINCRONIZAR FOTOS COM HOOK ============
  useEffect(() => {
    console.log(`📸 NovoLaudo: ${fotosDoHook.length} fotos do hook`);
  }, [fotosDoHook]);

  // ============ CARREGAR SUBSCRIPTION AO MONTAR ============
  useEffect(() => {
    if (user) {
      carregarSubscription();
    }
  }, [user, carregarSubscription]);

  // ============ VALIDAÇÕES ============
  const step1Complete = !!(
    formData.tipo_vistoria &&
    formData.responsavel &&
    formData.crea_cau &&
    formData.data_vistoria &&
    formData.cliente
  );

  const step2Complete = !!iaResult;

  // ============ CRIAR LAUDO (STEP 1 → STEP 2) ============
  const handleCriarLaudo = async () => {
    if (!user) {
      toast.error('Você precisa estar autenticado');
      return;
    }

    // ✅ VALIDAÇÃO 1: Verificar limite de laudos
    if (!podecriarLaudo()) {
      toast.error('Você atingiu o limite de laudos do seu plano');
      navigate('/planos');
      return;
    }

    // ✅ VALIDAÇÃO 2: Dados obrigatórios
    if (!step1Complete) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    try {
      setIsCreatingLaudo(true);

      // ✅ CRIAR LAUDO NO SUPABASE
      const conteudoInicial: RelatorioIA = {
        achados: [],
        resumo_executivo: formData.descricao || '',
        nivel_risco_geral: 'baixo',
      };

      const novoLaudo = await criarLaudo({
        cliente: formData.cliente,
        tipo_vistoria: formData.tipo_vistoria as TipoVistoria,
        data_vistoria: formData.data_vistoria,
        endereco: formData.endereco || undefined,
        responsavel: formData.responsavel || undefined,
        titulo: `${formData.tipo_vistoria} - ${formData.cliente}`,
        conteudo_json: conteudoInicial,
      });

      if (!novoLaudo) {
        toast.error('Erro ao criar laudo');
        return;
      }

      // ✅ REGISTRAR NO AUDIT LOG
      await registrarCriacaoLaudo(novoLaudo.id, {
        tipo_vistoria: formData.tipo_vistoria,
        cliente: formData.cliente,
      });

      console.log('🟢 Laudo criado:', novoLaudo.id);
      setLaudoId(novoLaudo.id);
      toast.success('Laudo criado! Agora adicione as evidências.');
      setActiveStep(1);
    } catch (err) {
      console.error('🔴 Erro ao criar laudo:', err);
      toast.error('Erro ao criar laudo');
    } finally {
      setIsCreatingLaudo(false);
    }
  };

  // ============ PROCESSAR ANÁLISE IA (STEP 2 → STEP 3) ============
  const handleProcessarIA = async (result: any) => {
    if (!laudoId) {
      toast.error('Laudo não foi criado corretamente');
      return;
    }

    try {
      const conteudoAtualizado: RelatorioIA = {
        achados: result.achados || [],
        resumo_executivo: result.resumo_executivo || formData.descricao || '',
        nivel_risco_geral: result.nivel_risco_geral || 'baixo',
      };

      // ✅ ATUALIZAR LAUDO COM RESULTADO DA IA
      const sucesso = await atualizarLaudo(laudoId, {
        conteudo_json: conteudoAtualizado,
      });

      if (!sucesso) {
        toast.error('Erro ao salvar análise IA');
        return;
      }

      // ✅ REGISTRAR NO AUDIT LOG
      await registrarAtualizacaoLaudo(laudoId, {
        acao: 'analise_ia_processada',
        fotos_count: fotosDoHook.length, // ✅ USAR fotosDoHook
        achados_count: conteudoAtualizado.achados.length,
      });

      // ✅ INCREMENTAR CONTADOR DE LAUDOS USADOS
      await incrementarLaudosUsados();

      console.log('🟢 Análise IA processada');
      setIaResult(conteudoAtualizado);
      toast.success('Análise IA concluída!');
      setActiveStep(2);
    } catch (err) {
      console.error('🔴 Erro ao processar IA:', err);
      toast.error('Erro ao processar análise IA');
    }
  };

  // ============ FINALIZAR LAUDO (STEP 3) ============
  const handleFinalizarLaudo = async () => {
    if (!laudoId) {
      toast.error('Laudo não foi criado corretamente');
      return;
    }

    try {
      const sucesso = await atualizarLaudo(laudoId, {
        status: 'finalizado',
      });

      if (!sucesso) {
        toast.error('Erro ao finalizar laudo');
        return;
      }

      await registrarAtualizacaoLaudo(laudoId, {
        acao: 'laudo_finalizado',
      });

      console.log('🟢 Laudo finalizado');
      toast.success('Laudo finalizado com sucesso!');

      setTimeout(() => {
        navigate('/historico');
      }, 1500);
    } catch (err) {
      console.error('🔴 Erro ao finalizar laudo:', err);
      toast.error('Erro ao finalizar laudo');
    }
  };

  // ============ CANCELAR CRIAÇÃO ============
  const handleCancelar = async () => {
    if (laudoId) {
      console.log('🟡 Laudo criado mas não finalizado:', laudoId);
    }
    navigate('/dashboard');
  };

  // ============ RENDER ============
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
          Novo Laudo
        </h1>

        {subscription && (
          <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            {subscription.laudos_used} / {subscription.laudos_limit} laudos usados
          </div>
        )}
      </div>

      <StepperAbas
        activeStep={activeStep}
        onStepClick={(step) => {
          if (step === 0) setActiveStep(0);
          if (step === 1 && step1Complete) setActiveStep(1);
          if (step === 2 && step2Complete) setActiveStep(2);
        }}
        step1Complete={step1Complete}
        step2Complete={step2Complete}
      />

      {activeStep === 0 && (
        <AbaInicial
          formData={formData}
          onChange={(updates) => setFormData((prev) => ({ ...prev, ...updates }))}
          onNext={handleCriarLaudo}
          isComplete={step1Complete}
          isLoading={isCreatingLaudo || laudosLoading}
          canCreate={podecriarLaudo()}
          onCancel={handleCancelar}
        />
      )}

      {activeStep === 1 && laudoId && (
        <EvidenciasTab
          fotos={fotosDoHook.map((f) => f.preview)} // ✅ PASSAR PREVIEWS DO HOOK
          onFotosChange={() => { }} // ✅ NÃO PRECISA MAIS (hook gerencia)
          onProcessed={handleProcessarIA}
          tipoLaudo={formData.tipo_vistoria as TipoVistoria}
          descricao={formData.descricao}
          laudoId={laudoId}
        />
      )}

      {activeStep === 2 && laudoId && iaResult && (
        <AbaRevisao
          iaResult={iaResult}
          fotos={fotosDoHook.map((f) => f.preview)} // ✅ PASSAR PREVIEWS DO HOOK
          formData={formData}
          laudoId={laudoId}
          onFinalize={handleFinalizarLaudo}
          onCancel={handleCancelar}
        />
      )}
    </div>
  );
}