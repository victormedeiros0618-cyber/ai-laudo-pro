// @ts-ignore: Deno is injected globally by Supabase Edge Functions
const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");

interface AnalysisRequest {
    imageBase64: string;
    tipoLaudo: string;
    descricao?: string;
}

interface AchadoTecnico {
    ambiente_setor: string;
    titulo_patologia: string;
    descricao_tecnica: string;
    gravidade: "baixo" | "medio" | "alto" | "critico";
    nota_g: number;
    nota_u: number;
    nota_t: number;
    gut_score: number;
    estimativa_custo: string;
    norma_nbr_relacionada: string;
    provavel_causa: string;
    recomendacao_intervencao: string;
}
interface AnalysisResponse {
    achados: AchadoTecnico[];
    resumo_executivo: string;
    nivel_risco_geral: "baixo" | "medio" | "alto" | "critico";
}

// @ts-ignore: Deno is injected globally by Supabase Edge Functions
Deno.serve(async (req: Request): Promise<Response> => {
    // ============ CORS ============
    if (req.method === "OPTIONS") {
        return new Response("ok", {
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
                "Access-Control-Max-Age": "86400",
            },
        });
    }

    try {
        if (req.method !== "POST") {
            return new Response(
                JSON.stringify({ error: "Método não permitido" }),
                { status: 405, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        const { imageBase64, tipoLaudo, descricao } = (await req.json()) as AnalysisRequest;

        if (!imageBase64) {
            return new Response(
                JSON.stringify({ error: "imageBase64 é obrigatório" }),
                { status: 400, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        if (!GEMINI_API_KEY) {
            throw new Error("GEMINI_API_KEY não configurada");
        }

        console.log("🟢 Analisando imagem com Gemini 2.5-Flash...");

        // ============ PROMPT OTIMIZADO ============
        const prompt = `Você é um engenheiro civil especialista em inspeção predial com 20+ anos de experiência.

TAREFA: Analise a imagem fornecida e identifique TODOS os problemas técnicos, patologias construtivas e deficiências visíveis.

RETORNE SEMPRE um JSON válido com esta estrutura EXATA (SEM markdown code fence):
{
  "achados": [
    {
      "ambiente_setor": "Local específico",
      "titulo_patologia": "Nome técnico do problema",
      "descricao_tecnica": "Descrição detalhada",
      "gravidade": "baixo|medio|alto|critico",
      "nota_g": 5,
      "nota_u": 5,
      "nota_t": 5,
      "gut_score": 125,
      "estimativa_custo": "R$ 1000 - R$ 5000",
      "norma_nbr_relacionada": "NBR 15575",
      "provavel_causa": "Causa raiz",
      "recomendacao_intervencao": "Ação recomendada"
    }
  ],
  "resumo_executivo": "Resumo geral em 2-3 linhas",
  "nivel_risco_geral": "baixo|medio|alto|critico"
}

REGRAS OBRIGATÓRIAS:
1. Se NÃO encontrar problemas, retorne "achados": [] (array vazio)
2. SEMPRE retorne um JSON válido e completo
3. Responda APENAS com o JSON, SEM markdown, SEM explicações adicionais
4. Tipo de Laudo: ${tipoLaudo}`;

        // ============ CHAMAR GEMINI ============
        const geminiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";

        const response = await fetch(geminiUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-goog-api-key": GEMINI_API_KEY,
            },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: prompt },
                        { inline_data: { mime_type: "image/jpeg", data: imageBase64 } },
                    ],
                }],
                generationConfig: {
                    temperature: 0.7,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 2048,
                },
            }),
        });

        console.log("🟢 Resposta Gemini recebida");

        if (!response.ok) {
            const errorText = await response.text();
            console.error("🔴 Erro Gemini:", response.status, errorText.substring(0, 200));

            return new Response(
                JSON.stringify({
                    achados: [],
                    resumo_executivo: "Erro ao processar imagem",
                    nivel_risco_geral: "baixo",
                }),
                { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        const geminiData = await response.json();
        let content = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;

        if (!content) {
            console.error("🔴 Conteúdo vazio do Gemini");

            return new Response(
                JSON.stringify({
                    achados: [],
                    resumo_executivo: "Nenhum problema técnico identificado",
                    nivel_risco_geral: "baixo",
                }),
                { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        console.log("🟢 Conteúdo extraído, tamanho:", content.length);

        // ============ EXTRAIR JSON (CORRIGIDO) ============
        let jsonMatch = content.match(/\{[\s\S]*\}/);

        // Se não encontrar, tenta remover markdown code fence
        if (!jsonMatch) {
            console.log("🟡 JSON não encontrado no primeiro regex, tentando remover markdown...");

            const cleanedContent = content
                .replace(/```json\n?/g, '')
                .replace(/```\n ?/g, '')
                .trim();

            console.log("🟡 Conteúdo limpo:", cleanedContent.substring(0, 200));

            jsonMatch = cleanedContent.match(/\{[\s\S]*\}/);
        }

        if (!jsonMatch) {
            console.error("🔴 JSON não encontrado. Conteúdo original:", content.substring(0, 500));

            return new Response(
                JSON.stringify({
                    achados: [],
                    resumo_executivo: "Erro ao extrair dados da análise",
                    nivel_risco_geral: "baixo",
                }),
                { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        console.log("🟢 JSON extraído com sucesso");

        let analysisResult: AnalysisResponse;

        try {
            analysisResult = JSON.parse(jsonMatch[0]);
        } catch (parseError) {
            console.error("🔴 Erro ao fazer parse do JSON:", parseError);

            return new Response(
                JSON.stringify({
                    achados: [],
                    resumo_executivo: "Erro ao processar resposta da IA",
                    nivel_risco_geral: "baixo",
                }),
                { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
            );
        }

        console.log("🟢 Análise concluída:", analysisResult.achados.length, "achados");

        return new Response(JSON.stringify(analysisResult), {
            status: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
            },
        });
    } catch (error) {
        console.error("🔴 Erro geral:", error);

        return new Response(
            JSON.stringify({
                achados: [],
                resumo_executivo: "Erro ao analisar imagem",
                nivel_risco_geral: "baixo",
            }),
            { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
        );
    }
});